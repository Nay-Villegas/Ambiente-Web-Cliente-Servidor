const estudiantes = [
    {
        nombre: "Maria",
        apellido: "Mora Perez",
        nota: 90
    },
    {
        nombre: "Pedro",
        apellido: "Sibaja Lopez",
        nota: 60
    },
    {
        nombre: "Marco",
        apellido: "Rojas Castro",
        nota: 78
    }
];

const tabla = document.getElementById("tablaEstudiantes");
const formulario = document.getElementById("formEstudiante");
const mensaje = document.getElementById("mensaje");

mostrarEstudiantes();
actualizarResumen();

formulario.addEventListener("submit", function(e) {

    e.preventDefault();

    const nombre = document.getElementById("nombre").value.trim();
    const apellido = document.getElementById("apellido").value.trim();
    const nota = Number(document.getElementById("nota").value);

    if(nombre === "" || apellido === "" || isNaN(nota)){
        mensaje.textContent = "Todos los campos son obligatorios";
        return;
    }

    if(nota < 0 || nota > 100){
        mensaje.textContent = "La nota debe estar entre 0 y 100";
        return;
    }

    estudiantes.push({
        nombre,
        apellido,
        nota
    });

    mensaje.textContent = "";

    formulario.reset();

    mostrarEstudiantes();
    actualizarResumen();
});

function mostrarEstudiantes(){

    tabla.innerHTML = "";

    estudiantes.forEach(estudiante => {

        let claseNota = "";

        if(estudiante.nota >= 80){
            claseNota = "aprobado";
        } else if(estudiante.nota < 65){
            claseNota = "reprobado";
        }

        tabla.innerHTML += `
        <tr>
            <td>${estudiante.nombre}</td>
            <td>${estudiante.apellido}</td>
            <td class="${claseNota}">
                ${estudiante.nota}
            </td>
        </tr>
        `;
    });
}

function actualizarResumen(){

    const notas = estudiantes.map(est => est.nota);

    const mayor = Math.max(...notas);
    const menor = Math.min(...notas);

    const promedio =
        notas.reduce((a, b) => a + b, 0) / notas.length;

    const mejorEstudiante =
        estudiantes.find(est => est.nota === mayor);

    document.getElementById("mayorNota").textContent =
        `Mayor nota: ${mejorEstudiante.nombre} ${mejorEstudiante.apellido} (${mayor})`;

    document.getElementById("promedio").textContent =
        `Promedio: ${promedio.toFixed(2)}`;

    document.getElementById("menorNota").textContent =
        `Nota más baja: ${menor}`;
}